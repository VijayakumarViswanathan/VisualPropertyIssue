﻿using System.Threading.Tasks;

namespace AutoCompleteWindowsReference.Interfaces
{
    public interface IMyService
    {
        Task DoSomethingAsync();
    }
}
