﻿using Xamarin.Forms;

namespace AutoCompleteWindowsReference.Interfaces
{
    public interface INavigationService
    {
        INavigation Current { get; }
    }
}
