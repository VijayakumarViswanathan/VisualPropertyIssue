﻿namespace AutoCompleteWindowsReference
{
    public static class Constants
    {
        public const string SyncFusionLicenseKey = "";
    }
}
