﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AutoCompleteWindowsReference.Views
{
    public partial class SecondPage : ContentPage
    {
        public SecondPage()
        {
            InitializeComponent();
        }
    }
}
