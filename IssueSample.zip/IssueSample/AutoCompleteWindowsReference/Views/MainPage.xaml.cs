﻿using Xamarin.Forms;

namespace AutoCompleteWindowsReference.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
