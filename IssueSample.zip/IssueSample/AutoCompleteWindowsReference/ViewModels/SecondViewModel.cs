﻿using MvvmHelpers;

namespace AutoCompleteWindowsReference.ViewModels
{
    public class SecondViewModel : BaseViewModel
    {
        public SecondViewModel()
        {
            Title = "Second Page";
        }
    }
}
